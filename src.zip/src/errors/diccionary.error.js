const errorDictionary = {
    INSUFFICIENT_STOCK: {
        code: 400,
        message: 'Insufficient stock for the requested quantity con custom error'
    }
    //mas errores despues 
};

export default errorDictionary;